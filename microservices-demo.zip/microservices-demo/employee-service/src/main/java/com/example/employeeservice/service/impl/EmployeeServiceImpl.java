package com.example.employeeservice.service.impl;

import com.example.employeeservice.dto.ApiResponseDto;
import com.example.employeeservice.dto.DepartmentDto;
import com.example.employeeservice.dto.EmployeeDto;
import com.example.employeeservice.entity.Employee;
import com.example.employeeservice.repository.EmployeeRepository;
import com.example.employeeservice.service.EmployeeService;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@AllArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    private EmployeeRepository employeeRepository;

    private ModelMapper modelMapper;

//    private RestTemplate restTemplate;

    private ApiClient apiClient;

    @Override
    public EmployeeDto saveEmployee(EmployeeDto employeeDto) {
        Employee employeeEntity = modelMapper.map(employeeDto,Employee.class);
        return modelMapper.map(employeeRepository.save(employeeEntity), EmployeeDto.class);
    }

    @Override
    @CircuitBreaker(name ="${spring.application.name}", fallbackMethod = "getDefaultDepartment")
    public ApiResponseDto getEmployee(Long employeeId) {


        EmployeeDto employeeDto = modelMapper.
                map(employeeRepository.findById(employeeId), EmployeeDto.class);

        //API call to departmentService based on the employee's departmentCode
//        ResponseEntity<DepartmentDto> responseEntity = restTemplate.
//                getForEntity("http://localhost:8080/api/departments/" + employeeDto.getDepartmentCode(), DepartmentDto.class);
//
//
//        DepartmentDto departmentDto = responseEntity.getBody();

        DepartmentDto departmentDto = apiClient.getDepartmentByCode(employeeDto.getDepartmentCode());

        ApiResponseDto apiResponseDto = new ApiResponseDto();
        apiResponseDto.setEmployeeDto(employeeDto);
        apiResponseDto.setDepartmentDto(departmentDto);

        return apiResponseDto;


    }

    public  ApiResponseDto getDefaultDepartment(Long employeeId, Exception exception){
        EmployeeDto employeeDto = modelMapper.
                map(employeeRepository.findById(employeeId), EmployeeDto.class);

        DepartmentDto departmentDto = new DepartmentDto();
        departmentDto.setDepartmentName("Default Department");
        departmentDto.setDepartmentDescription("Since Department service is down, please check after sometime");
        departmentDto.setDepartmentCode("DEFAULT_DEPARTMENT");

        ApiResponseDto apiResponseDto = new ApiResponseDto();
        apiResponseDto.setEmployeeDto(employeeDto);
        apiResponseDto.setDepartmentDto(departmentDto);

        return apiResponseDto;
    }
}
