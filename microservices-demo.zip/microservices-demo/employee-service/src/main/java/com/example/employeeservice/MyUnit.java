package com.example.employeeservice;

public class MyUnit {
    //    public static void main(String[] args) {
//
//        System.out.println(concatenate("John", "Doe"));
//    }
    public String concatenate(String firstName, String lastName){
        int j = addNumbers();
        return firstName + lastName;
    }

    public int addNumbers() {
        return 4;
    }


}
