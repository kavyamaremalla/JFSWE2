package com.example.employeeservice;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.when;

public class MyUnitTest {

    @BeforeEach
    public void initMocks() {
        MockitoAnnotations.initMocks(this);
    }


    @Mock
    private MyUnit myUnitMock;

    @InjectMocks
    private MyUnit myUnit;

    @Test

    public void testConcatenate() {
//        MyUnit myUnit = new MyUnit();

        when(myUnitMock.addNumbers()).thenReturn(4);

        String result = myUnit.concatenate("John", "Doe");
        Assertions.assertEquals("JohnDoe", result);

        Assertions.assertEquals(4, myUnitMock.addNumbers());


    }
}

