package org.example;

import org.example.hibernate.models.Orders;
import org.example.hibernate.models.Persons;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class HibernateDemo {
    public static void main(String[] args) {

        Configuration configuration = new Configuration().configure()
                .addAnnotatedClass(Persons.class)
                .addAnnotatedClass(Orders.class);

        Persons persons = null;

        SessionFactory sessionFactory = configuration.buildSessionFactory();

        Session session = sessionFactory.openSession();

        Transaction transaction = session.beginTransaction();

        persons = session.get(Persons.class,1);

        transaction.commit();

        System.out.println(persons.getOrders().get(0).getOrderDetails());
    }
}