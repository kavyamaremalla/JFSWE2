package org.spring.jpa.demo.service.impl;

import lombok.AllArgsConstructor;
import org.spring.jpa.demo.entity.User;
import org.spring.jpa.demo.repository.UserRepository;
import org.spring.jpa.demo.service.UserService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class UserServiceImpl implements UserService {

    private UserRepository userRepository;

    @Override
    public User createUser(User user) {
        return userRepository.save(user);
    }

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public User getUserById(Long userId) {
        return userRepository.findById(userId).get();
    }

    @Override
    public User updateUser(User newUserDetails) {

        User existingUser = userRepository.findById(newUserDetails.getId()).get();

        existingUser.setFirstName(newUserDetails.getFirstName());
        existingUser.setLastName(newUserDetails.getLastName());
        existingUser.setEmail(newUserDetails.getEmail());

        return userRepository.save(existingUser);
    }

    @Override
    public void deleteUser(Long userId) {
        userRepository.deleteById(userId);
    }
}
