package org.spring.jpa.demo.contoller;

import lombok.AllArgsConstructor;
import org.spring.jpa.demo.entity.User;
import org.spring.jpa.demo.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor
@RequestMapping("api/users")
public class UserController {

    private UserService userService;

    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user) {

        User savedUser = userService.createUser(user); //ctrl + alt + b to go inside a method

        return new ResponseEntity<>(savedUser, HttpStatus.CREATED);

        //get all users, get single user,update,delete
    }
}
