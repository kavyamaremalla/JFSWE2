package org.spring.jpa.demo.contoller;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.spring.jpa.demo.dto.UserDto;
import org.spring.jpa.demo.entity.User;
import org.spring.jpa.demo.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("api/users")
public class UserController {

    private UserService userService;

    @PostMapping("/createUser")
    public ResponseEntity<UserDto> createUser(@Valid @RequestBody UserDto userDto){
        //insert data into user
        UserDto saveUser = userService.createUser(userDto); //ctrl + alt + b to go inside a method
        return new ResponseEntity<>(saveUser, HttpStatus.CREATED);
    }

    @GetMapping("/getAllUsers")
    public ResponseEntity<List<UserDto>> getAllUsers(){
        List<UserDto> userList = userService.getAllUsers();
        return new ResponseEntity<>(userList, HttpStatus.OK);
    }

    @GetMapping("/getUserById/{id}")
    public ResponseEntity<UserDto> getUserById(@PathVariable("id") Long id) {
        UserDto userDto = userService.getUserById(id);
        return new ResponseEntity<>(userDto, HttpStatus.OK);
    }

    @PutMapping("/updateUserById/{id}")
    public ResponseEntity<UserDto> updateUser(@PathVariable("id") Long id , @Valid @RequestBody UserDto userDto){
        userDto.setId(id);
        UserDto updateUserDto = userService.updateUser(userDto);
        return new ResponseEntity<>(updateUserDto, HttpStatus.OK);
    }


    @DeleteMapping("/deleteUserById/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable("id") Long id){
        userService.deleteUser(id);
        return new ResponseEntity<>("User Deleted Successfully", HttpStatus.OK);
    }
}
