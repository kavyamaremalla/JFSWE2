package org.spring.jpa.demo.service;


import org.spring.jpa.demo.dto.UserDto;

import java.util.List;

public interface UserService {

    UserDto createUser(UserDto UserDto);

    List<UserDto> getAllUsers();

    UserDto getUserById(Long UserDtoId);

    UserDto updateUser(UserDto UserDto);

    void deleteUser(Long UserDtoId);
}
