package org.spring.data.mongodb.demo.repository;

import org.spring.data.mongodb.demo.dto.Product;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ProductRepository extends MongoRepository<Product, String> {
}
