package org.spring.data.mongodb.demo.controller;

import org.spring.data.mongodb.demo.dto.Product;
import org.spring.data.mongodb.demo.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ProductController {

    @Autowired
    private ProductRepository repository; //call repo from service layer, TODO

    @PostMapping("/addProduct")
    public String saveProduct(@RequestBody Product product){ //return response entity
        repository.save(product);//add a service layer & call repo from service layer
        return "Product Added successfully"; //return proper http status with response entity
    }

    @PostMapping("/addProductList")
    public String saveAllProducts(@RequestBody List<Product> productList){ //return response entity
        repository.saveAll(productList);//add a service layer & call repo from service layer
        return "Product Added successfully"; //return proper http status with response entity
    }


    @GetMapping("/findAllProducts")
    public List<Product> getProductList(){
        return repository.findAll();
    }

    @DeleteMapping("/delete/{id}")
    public  String deleteProduct(@PathVariable String id){
        repository.deleteById(id);
        return "Product Deleted Successfully";
    }
}
