package com.example.spring.thymeleaf.service.impl;

import com.example.spring.thymeleaf.dto.EmployeeDto;
import com.example.spring.thymeleaf.entity.Employee;
import com.example.spring.thymeleaf.repository.EmployeeRepository;
import com.example.spring.thymeleaf.service.EmployeeService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;


    @Autowired
    private ModelMapper modelMapper;

    @Override
    public void save(EmployeeDto employeeDto) {
//        Employee employee = modelMapper.map(employeeDto, Employee.class);
        employeeRepository.save(modelMapper.map(employeeDto, Employee.class));
    }

    @Override
    public List<Employee> getAllEmployee() {
        return employeeRepository.findAll();
    }

    @Override
    public EmployeeDto getById(Long id) {

        Optional<Employee> optionalEmployee = employeeRepository.findById(id);

        Employee employee = null;

        if(optionalEmployee.isPresent()){
            employee = optionalEmployee.get();
        }else{
            throw new RuntimeException("Employee not found for provided id, please check id : " + id);
        }

        return modelMapper.map(employee, EmployeeDto.class);
    }

    @Override
    public void deleteById(Long id) {
        Optional<Employee> optionalEmployee = employeeRepository.findById(id);

         if(optionalEmployee.isPresent()){
            employeeRepository.deleteById(id);
        }else{
            throw new RuntimeException("Employee not found for provided id, please check id : " + id);
        }
    }
}
