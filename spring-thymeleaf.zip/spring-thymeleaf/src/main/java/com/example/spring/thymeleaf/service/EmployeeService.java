package com.example.spring.thymeleaf.service;

import com.example.spring.thymeleaf.dto.EmployeeDto;
import com.example.spring.thymeleaf.entity.Employee;

import java.util.List;

public interface EmployeeService {

    void save(EmployeeDto employeeDto);

    List<Employee> getAllEmployee();

    EmployeeDto getById(Long id);

    void deleteById(Long id);
}
