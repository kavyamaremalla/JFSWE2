package com.example.spring.thymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringThymeleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
