package com.springboot.test;

import com.springboot.ConcatenateString;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ConcatenateStringTest {
    ConcatenateString concatenateString;

    @BeforeEach
    public void beforeAll(){
        concatenateString = new ConcatenateString();
    }

    @Test
     void testConcatenate(){
        String actualResult = concatenateString.concatenate("John", "Doe");
        Assertions.assertEquals("JohnDoe", actualResult);
    }

    @Test
     void testConcatenateWithEmptyStrings(){
        String actualResult = concatenateString.concatenate("", "");
        Assertions.assertEquals("", actualResult);
    }

    @Test
    void testConcatenateWithFirstNameEmpty(){
        String actualResult = concatenateString.concatenate("", "Doe");
        Assertions.assertEquals("Doe", actualResult);
    }

    @Test
    void testConcatenateWithLastNameEmpty(){
        String actualResult = concatenateString.concatenate("John", "");
        Assertions.assertEquals("John", actualResult);
    }

    @Test
    void testConcatenateWithNullFirstName(){
        String actualResult = concatenateString.concatenate(null, "Doe");
        Assertions.assertEquals("Doe", actualResult);
    }

    @Test
    void testConcatenateWithNullLastName(){
        String actualResult = concatenateString.concatenate("John", null);
        Assertions.assertEquals("John", actualResult);
    }

    @Test
    void testConcatenateWithBothNull(){
        String actualResult = concatenateString.concatenate(null, null);
        Assertions.assertEquals("", actualResult);
    }


}
