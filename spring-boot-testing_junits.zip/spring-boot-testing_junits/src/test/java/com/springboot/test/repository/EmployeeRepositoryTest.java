package com.springboot.test.repository;

import com.springboot.model.Employee;
import com.springboot.repository.EmployeeRepository;
import org.mockito.InjectMocks;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

@DataJpaTest
public class EmployeeRepositoryTest {

    @InjectMocks
    private EmployeeRepository  employeeRepository;

    private Employee employee;
}
