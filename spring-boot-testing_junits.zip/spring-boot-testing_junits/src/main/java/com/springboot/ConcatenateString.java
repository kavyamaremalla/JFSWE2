package com.springboot;

public class ConcatenateString {

    public static void main(String[] args) {
//        ConcatenateString concatenateString = new ConcatenateString();
//        System.out.println(concatenateString.concatenate("John", null));
    }

    public String concatenate(String firstName, String lastName) {

        if(firstName == null){
            firstName = "";
        }

        if (lastName == null){
            lastName = "";
        }

        return firstName + lastName;
    }
}
