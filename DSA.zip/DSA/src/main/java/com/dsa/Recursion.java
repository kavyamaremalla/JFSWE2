package com.dsa;

public class Recursion {

    public static void main(String[] args) {
        int result = factorial(3);

        System.out.println(result);

        int count=5;
        System.out.print(n1+" "+n2);//printing 0 and 1
        printFibonacci(count-2);

        add(5);

    }

    public static void add(int i) {
        if (i != 0) {
            System.out.println("DSA Intro Session: " + i);
            add(i - 1);
        }
    }
    public static int factorial(int i) {

        //base case
        if (i == 0) {
            return 1;
        } else {
            return i * factorial(i - 1);
        }
    }


    static int n1 = 0, n2 = 1, n3 = 0;

    static void printFibonacci(int count) {
        if (count > 0) {
            n3 = n1 + n2;
            n1 = n2;
            n2 = n3;
            System.out.print(" " + n3);
            printFibonacci(count - 1);
        }
    }

}
