package com.dsa;

public class BubbleSort {

    public static void main(String[] args) {

        int[] arr = {3, 4, 1, 1, 9, -1};

        for (int i = 0; i < arr.length; i++) {
            for (int j = i + 1; j < arr.length; j++) { //j=0 gives you descending order
                if(arr[i] > arr[j]){
                    int temp = arr[j];
                    arr[j] = arr[i];
                    arr[i] = temp;
                }
            }
        } // O(n) * O(n) -> O(n2)

        for (int j : arr) {
            System.out.println(j);
        } // --> O(n)

    }
}

//time -> O(n2) n square
// space -> O(1)
