package com.dsa;

public class BinarySearch {
    public static void main(String[] args) {

        int x = 10;
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        //                                   m l          h
        System.out.println(binarySearch(arr, 0, arr.length, x));
    }

    public static int binarySearch(int[] arr, int low, int high, int x) {
        if (low > high) {
            return -1;
        } else {
            int mid = (low + high) / 2;
            if (arr[mid] == x) {
                return mid;
            } else {
                return arr[mid] > x
                        ? binarySearch(arr, low, mid - 1, x)
                        : binarySearch(arr, mid + 1, high, x);
            }
        }
    }
}
