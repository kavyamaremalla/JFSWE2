package com.dsa;

public class LinearSearch {

    public static void main(String[] args) {
        int x = 4;
        int [] arr = {1,2,3,4,5,6};

        for(int j = 0; j < arr.length; j++) {
            if (arr[j] == x) {
                System.out.println("Found x " + x);
            }
        }


    }

}
