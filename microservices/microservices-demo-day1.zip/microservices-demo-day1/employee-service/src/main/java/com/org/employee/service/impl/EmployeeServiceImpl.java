package com.org.employee.service.impl;

import com.org.employee.dto.ApiResponseDto;
import com.org.employee.dto.EmployeeDto;
import com.org.employee.service.EmployeeService;

public class EmployeeServiceImpl implements EmployeeService {
    @Override
    public EmployeeDto saveEmployee(EmployeeDto employeeDto) {
        return null;
    }

    @Override
    public ApiResponseDto getEmployee(Long employeeId) {
        return null;
    }
}
