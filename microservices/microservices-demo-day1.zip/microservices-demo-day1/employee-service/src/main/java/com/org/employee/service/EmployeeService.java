package com.org.employee.service;

import com.org.employee.dto.ApiResponseDto;
import com.org.employee.dto.EmployeeDto;

public interface EmployeeService {

    EmployeeDto saveEmployee(EmployeeDto employeeDto);

    ApiResponseDto getEmployee(Long employeeId);
}
