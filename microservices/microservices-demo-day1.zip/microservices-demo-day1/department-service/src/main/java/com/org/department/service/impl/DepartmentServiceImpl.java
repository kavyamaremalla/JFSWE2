package com.org.department.service.impl;

import com.org.department.dto.DepartmentDto;
import com.org.department.entity.Department;
import com.org.department.repository.DepartmentRepository;
import com.org.department.service.DepartmentService;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class DepartmentServiceImpl implements DepartmentService {

    private DepartmentRepository repository;

    private ModelMapper modelMapper;

    @Override
    public DepartmentDto saveDepartment(DepartmentDto departmentDto) {

//        Department department = getDepartmentEntityFromDto(departmentDto);
//        repository.save(department);
//        return getDepartmentDtoFromEntity(department);

        Department department = modelMapper.map(departmentDto, Department.class); //getDepartmentDtoFromEntity

        return modelMapper.map(repository.save(department),DepartmentDto.class); //getDepartmentEntityFromDto

    }

    private  DepartmentDto getDepartmentDtoFromEntity(Department department) {
        DepartmentDto savedObject = new DepartmentDto();
        savedObject.setId(department.getId());// you will have id since you save to db, you get an Id
        savedObject.setDepartmentCode(department.getDepartmentCode());
        savedObject.setDepartmentName(department.getDepartmentName());
        savedObject.setDepartmentDescription(department.getDepartmentDescription());

        return savedObject;
    }

    private  Department getDepartmentEntityFromDto(DepartmentDto departmentDto) {
        Department department = new Department();
        department.setId(departmentDto.getId()); //id is null, after saving you will have id
        department.setDepartmentName(departmentDto.getDepartmentName());
        department.setDepartmentCode(departmentDto.getDepartmentCode());
        department.setDepartmentDescription(departmentDto.getDepartmentDescription());
        return department;
    }

    @Override
    public DepartmentDto getDepartmentByCode(String departmentCode) {
        return modelMapper.map(repository.findByDepartmentCode(departmentCode),DepartmentDto.class);
    }
}
