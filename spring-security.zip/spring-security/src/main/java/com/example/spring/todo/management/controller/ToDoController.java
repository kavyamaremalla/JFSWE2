package com.example.spring.todo.management.controller;

import com.example.spring.todo.management.dto.LoginRequestDto;
import com.example.spring.todo.management.dto.ToDoDto;
import com.example.spring.todo.management.security.JWTUtil;
import com.example.spring.todo.management.service.ToDoService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("api/todos")
public class ToDoController {

    private ToDoService toDoService;

    private AuthenticationManager authenticationManager;

    private JWTUtil jwtUtil;


    @PostMapping("jwt")
    public  ResponseEntity<String> login(@RequestBody LoginRequestDto requestDto) {

        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(
                requestDto.getUsername(),
                requestDto.getPassword()
        );

        authenticationManager.authenticate(token);

        String jwt = jwtUtil.generate(requestDto.getUsername());

        return ResponseEntity.ok(jwt);

    }
        @PreAuthorize("hasRole(\"ADMIN\")")
    @PostMapping("/addTask")
    public ResponseEntity<ToDoDto> addTodoTask(@RequestBody ToDoDto toDoDto){
        ToDoDto savedToDoTask = toDoService.addToDoTask(toDoDto);
        return new ResponseEntity<>(savedToDoTask, HttpStatus.CREATED);
    }

    @PreAuthorize("hasAnyRole(\"ADMIN\", \"USER\")")
    @GetMapping("/getAllTasks")
    public ResponseEntity<List<ToDoDto>> getAllToDos(){
        List<ToDoDto> toDoDtoList = toDoService.getAllToDoTasks();
        return new ResponseEntity<>(toDoDtoList,HttpStatus.OK);
    }
}
