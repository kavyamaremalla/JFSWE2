package com.example.spring.todo.management.service;


import com.example.spring.todo.management.dto.ToDoDto;

import java.util.List;

public interface ToDoService {
    ToDoDto addToDoTask(ToDoDto toDoDto);

    ToDoDto getToDoTask(Long id);

    List<ToDoDto> getAllToDoTasks();

    ToDoDto updateToDoTask(ToDoDto toDoDto, Long id);

    void deleteToDoTask(Long id);
}
