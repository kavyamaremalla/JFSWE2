package com.example.spring.todo.management.repository;

import com.example.spring.todo.management.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Long> {
}
