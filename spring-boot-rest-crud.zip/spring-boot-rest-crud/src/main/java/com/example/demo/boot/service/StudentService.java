package com.example.demo.boot.service;

public class StudentService {
}
