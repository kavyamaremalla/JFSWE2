package com.example.demo.boot.repository;

public class StudentRepository {
}
