package com.spring.demo;

public interface WishService {

      String getDailyWish();
}
