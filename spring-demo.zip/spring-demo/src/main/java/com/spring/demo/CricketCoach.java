package com.spring.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

@Component("myCricketCoach")
@Scope("prototype")
public class CricketCoach implements Coach {

//    @Autowired
    private WishService wishService;

    @Value("${email}")
    private String email;



    @Autowired
    public CricketCoach(@Qualifier("happyWishService") WishService wishService) {
        this.wishService = wishService;
    }



    public String getEmail() {
        return email;
    }


    public void setEmail(String email) {
        this.email = email;
    }


    @PostConstruct
    public void startUpMethod(){
        System.out.println("Started");
    }

    @PreDestroy
    public void destroyMethod(){
        System.out.println("Destroyed");
    }

    public WishService getWishService() {
        return wishService;
    }

//    @Autowired
    public void setWishService(WishService wishService) {
        this.wishService = wishService;
    }

    public String getDailyWorkOut(){
        return "Batting practice";
    }

    @Override
    public String dailyWish() {
        return wishService.getDailyWish();
    }
}
