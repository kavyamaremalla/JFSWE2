package com.spring.demo;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("myFootBallCoach")
public class FootBallCoach implements Coach{

    private WishService wishService;

    public FootBallCoach(@Qualifier("badWishService") WishService wishService) {
        this.wishService = wishService;
    }

    public WishService getWishService() {
        return wishService;
    }

    public void setWishService(WishService wishService) {
        this.wishService = wishService;
    }

    public String getDailyWorkOut(){
        return "Kicking practice";
    }

    @Override
    public String dailyWish() {
        return wishService.getDailyWish();
    }
}
