package com.spring.demo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MyApp {

    public static void main(String[] args) {

//        CricketCoach cricketCoach =  new CricketCoach();
//
//        cricketCoach.setWishService(new HappyWishService());
//
//        System.out.println(cricketCoach.getDailyWorkOut());
//        System.out.println(cricketCoach.dailyWish());
//
//        FootBallCoach footBallCoach = new FootBallCoach(new HappyWishService());
//        System.out.println(footBallCoach.dailyWish());


//        Coach cricketCoach =  new CricketCoach();
//        System.out.println(cricketCoach.getDailyWorkOut());
//
//        Coach footBallCoach = new FootBallCoach();
//        System.out.println(footBallCoach.getDailyWorkOut());
//
//        Coach coach;
//
//        String coachSport = "cricket";
//
//        if (coachSport.equals("cricket")){
//            coach = new CricketCoach();
//        }else{
//            coach = new FootBallCoach();
//        }

        AnnotationConfigApplicationContext context = new
                AnnotationConfigApplicationContext(SportsConfig.class);

        CricketCoach cricketCoach = context.getBean("myCricketCoach", CricketCoach.class);
        System.out.println(cricketCoach.dailyWish());
        System.out.println(cricketCoach.getEmail());

        Coach footBallCoach = context.getBean("myFootBallCoach", Coach.class);
        System.out.println(footBallCoach.dailyWish());

        //singleton

        Coach cricketCoach1 = context.getBean("myCricketCoach", Coach.class);
        Coach cricketCoach2 = context.getBean("myCricketCoach", Coach.class);

        System.out.println(cricketCoach1);
        System.out.println(cricketCoach2);

        context.close();

    }
}
