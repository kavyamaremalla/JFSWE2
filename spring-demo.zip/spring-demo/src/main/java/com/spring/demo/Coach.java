package com.spring.demo;

public interface Coach {
     String getDailyWorkOut();

     String dailyWish();
}
