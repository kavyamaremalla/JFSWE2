const fetchUserInfo = async () => {
  try {
    const response = await fetch("https://reqres.in/api/users?page=2")

    //parsing the json response
    const useData = await response.json(); //async api
  
    console.log(useData);
  } catch (error) {
    console.log(error.message);
  }

}

// fetchUserInfo();

fetch('https://reqres.in/api/users?page=2')
  .then((res) => res.json())
  .then((res) => console.log(res));