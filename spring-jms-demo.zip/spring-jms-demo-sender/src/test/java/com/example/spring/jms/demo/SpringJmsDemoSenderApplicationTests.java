package com.example.spring.jms.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJmsDemoSenderApplicationTests {

	@Test
	void contextLoads() {
	}

}
