package com.example.webflux.demo;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

import java.util.List;

public class FluxMonoGenerativeService {

    public static void main(String[] args) {
        FluxMonoGenerativeService service  =  new FluxMonoGenerativeService();
//        service.namesFlux(); // calling publisher & seeing what happens internally
//        System.out.println("Called namesFlux method");
//        service.namesFlux().subscribe(s -> System.out.println(s.length() + " " + s)); // calling your subscriber
        service.nameMono().subscribe(System.out::println);
//
//        Tuple2<String, String> tuple = Tuple2.of("Hello", "World");
//        System.out.println(tuple.getT1() + " " + tuple.getT2());
    }

    public Flux<String> namesFlux(){
        return Flux.fromIterable(List.of("John", "Peter", "Harry", "Doe"))
                .map(String::toUpperCase)
                .filter(name -> name.length()>3)
                .log();
    }

    public Mono<String> nameMono(){
        return Mono.just("Zack" ).log();
    }
}
