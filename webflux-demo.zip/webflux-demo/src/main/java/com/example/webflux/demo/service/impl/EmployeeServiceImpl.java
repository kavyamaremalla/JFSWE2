package com.example.webflux.demo.service.impl;

import com.example.webflux.demo.dto.EmployeeDto;
import com.example.webflux.demo.entity.Employee;
import com.example.webflux.demo.repository.EmployeeRepository;
import com.example.webflux.demo.service.EmployeeService;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@AllArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    private EmployeeRepository employeeRepository;

    private ModelMapper modelMappper;

    @Override
    public Mono<EmployeeDto> saveEmployee(EmployeeDto employeeDto) {
        Employee employee = modelMappper.map(employeeDto, Employee.class);
        Mono<Employee> employeeMono = employeeRepository.save(employee);

        return employeeMono
                .map(employeeEntity -> modelMappper.map(employeeEntity, EmployeeDto.class));
    }

    @Override
    public Mono<EmployeeDto> getEmployeeById(String employeeId) {
        return employeeRepository.findById(employeeId)
                .map(employeeEntity -> modelMappper.map(employeeEntity, EmployeeDto.class));
    }

    @Override
    public Flux<EmployeeDto> getAllEmployees() {
        return employeeRepository.findAll()
                .map(employeeEntity -> modelMappper.map(employeeEntity,EmployeeDto.class));
    }

    //task
    @Override
    public Mono<EmployeeDto> updateEmployee(EmployeeDto employeeDto, String employeeId) {
        return null;
    }

    @Override
    public Mono<Void> deleteEmployee(String employeeId) {
        return null;
    }
}
