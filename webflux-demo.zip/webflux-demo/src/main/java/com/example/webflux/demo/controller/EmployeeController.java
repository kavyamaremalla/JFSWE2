package com.example.webflux.demo.controller;

import com.example.webflux.demo.dto.EmployeeDto;
import com.example.webflux.demo.service.EmployeeService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

import java.time.Duration;
import java.util.stream.Stream;

@RestController
@RequestMapping("api/employees")
@AllArgsConstructor
public class EmployeeController {

    private EmployeeService employeeService;

    @PostMapping("/saveEmployee")
    @ResponseStatus(value = HttpStatus.CREATED)
    public Mono<EmployeeDto>  saveEmployee(@RequestBody EmployeeDto employeeDto){
        return employeeService.saveEmployee(employeeDto);
    }

    @GetMapping("{id}")
    @ResponseStatus(value = HttpStatus.OK)
    public Mono<EmployeeDto>  getEmployee(@PathVariable("id") String employeeId){
        return employeeService.getEmployeeById(employeeId);
    }

    //Server side Events -> stream events
    @GetMapping(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    @ResponseStatus(value = HttpStatus.OK)
    public Flux<EmployeeDto> streamAllUsers(){
        return employeeService.getAllEmployees()
                .flatMap(employeeDto -> Flux.zip(
                        Flux.interval(Duration.ofSeconds(2)),Flux.fromStream(Stream.generate(() -> employeeDto))
                )).map(Tuple2::getT2);
    }
}
